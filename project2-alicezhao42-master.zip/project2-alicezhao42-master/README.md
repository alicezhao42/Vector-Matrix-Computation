# MIE250 Project2

Please see the assignment description posted on Quercus for instructions.
