import linalg.LinAlgException;
import linalg.Matrix; // This is Matrix from the linear algebra package you are writing 
import linalg.Vector; // This is Vector from the linear algebra package you are writing 

/** This is a small example of test cases.  Write your own test cases to understand all
 *  of the methods in Matrix and Vector.  To test correctness of your implementation,  
 *  see if the output on your tests matches the results of the same tests on the solution
 *  (e.g., see TestLinAlgSoln which provides results for the solution by importing 
 *         soln.Matrix and soln.Vector as opposed to linalg.Matrix and linalg.Vector
 *         that you are writing).
 * 
 * @author ssanner@mie.utoronto.ca
 *
 */
public class TestLinAlg {

	public static void main(String[] args) {
		try {
			// Note: you need to write your own tests, this is only a small sample and it does not
			//       test all cases that throw an Exception as required by JavaDoc comments.
			Vector v = new Vector("[ 1 2 3 4 5 4 ]");
			Vector t = new Vector("[ 2 7 5 3 1 7 ]");
			Vector i = new Vector("[ 0 3 3 1 0 3 ]");
			
			System.out.println(i.get(0)); 
			//System.out.println(i.get(6)); 
			//System.out.println(i.get(-1)); 
			//i.set(0,1);
			//i.set(6,1);
			//i.set(-1,1);
			//t.changeDim(0); 
			//t.changeDim(1);
			//i.changeDim(100000);
			t.elementwiseAddInPlace(i);
			
			System.out.println(v);
			v.changeDim(4);
			t.changeDim(9);
			System.out.println(t);
			System.out.println(v.getDim()); 
			System.out.println(t.getDim());
			System.out.println(v.get(0)); 
			System.out.println(t.get(4)); 
			t.set(5,5);
			System.out.println("1. test constructor and toString(): " + v); // This automatically invokes v.toString()!
			System.out.println("2. test scalar addition: " + v.scalarAdd(7));
			System.out.println("3. ensure v was not modified: " + v);
			v.scalarAddInPlace(2);
			System.out.println("4. now v should be modified: " + v);
			
			v.changeDim(5);
			t.changeDim(5);
			i.changeDim(5);
			
			v.scalarAddInPlace(3); 
			System.out.println(v);
			
			System.out.println(t.scalarAdd(4));
			System.out.println(t);
			
			v.scalarMultInPlace(3);
			System.out.println(v);
			System.out.println(v.scalarMult(2)); 
			
			v.elementwiseAddInPlace(t); 
			System.out.println(v);
			
			System.out.println(v.elementwiseAdd(i)); 
			
			System.out.println("fdjksf " + v);
			System.out.println(i);
			i.elementwiseMultInPlace(v);
			System.out.println(i);
			
			System.out.println(i.elementwiseMult(t)); 
			System.out.println(i); 
			System.out.println(t); 
			
			//System.out.println(i.InnerProd(v,i));

			
			
			Matrix m = Matrix.GetIdentity(5);
			//System.out.println(m.getRow(4)); 
			System.out.println("5. identity matrix m:\n" + m);
			System.out.println("6. still identity after self-multiply:\n" + Matrix.Multiply(m, m)); 
			
			m.set(2, 0, 2);
			m.set(0, 2, 3);
			m.set(4, 0, 5);
			m.set(1, 4, 10);
			m.set(0, 3, 6);
			m.set(0, 0, 5);
			
			v.changeDim(5);
			
			System.out.println("7. m should be modified:\n" + m); // Remember: this automatically invokes m.toString()!
			System.out.println("8. result should not be the identity:\n" + Matrix.Multiply(m, m));
			System.out.println("9. example matrix/vector multiply: " + Matrix.Multiply(m, v));
			
			Matrix m2 = new Matrix(m);
			System.out.println("10. should be equal: " + m2.equals(m));
			m2.set(0, 1, 2d);
			System.out.println("11. should not be equal: " + m2.equals(m));
			
			Matrix m3 = new Matrix(5,4);
			m3.set(2, 1, 2.0);
			m3.set(2, 3, 3.0);
			m3.set(3, 0, 10.0);
			m3.set(4, 0, 11.0);
			System.out.println(m3.getNumCols());
			System.out.println(m2.getNumCols());
			System.out.println(m3.getNumRows());
			System.out.println(m2.getNumRows());
			System.out.println(m3.get(0,3));
			Matrix m4 = m3.transpose();
			System.out.println(m4.get(0,1));
			System.out.println(m3.getRow(2));
			Matrix d = Matrix.GetIdentity(5);
			Matrix c = new Matrix(4,5);
			c.set(2, 1, 2.0);
			c.set(2, 3, 3.0);
			c.set(3, 0, 10.0);
			c.set(2, 0, 11.0);
			System.out.println(Matrix.Multiply(c,d)); 
			
			
			m4.set(3, 4, 2.0);
			m4.set(0, 2, 6);
			Matrix m5 = new Matrix(5,4);
			m5.set(2, 1, 2.0);
			Matrix m6 = new Matrix(5,4);
			m6.set(2, 1, 2.0);
			System.out.println("12. should be 4 X 5:\n" + m4);
			System.out.println("13. should be 5 X 5:\n" + Matrix.Multiply(m3, m4));
			System.out.println("14. should work:\n" + Matrix.Multiply(m4, v));
			System.out.println("16. should work:\n" + Matrix.Multiply(d, v));
			System.out.println("14. should work:\n" + Matrix.Multiply(c, i));
			System.out.println("10. should be equal: " + m5.equals(m6));
			System.out.println(m3.equals(m4));
			System.out.println("15. should throw Exception: " + Matrix.Multiply(m3, v));
			
		
		} catch (LinAlgException e) {
			System.out.println("EXCEPTION: " + e.getMessage());
			System.exit(1); // Exits the program
		}
	}

}
