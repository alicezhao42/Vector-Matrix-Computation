package linalg;

/*** A class that represents a two dimensional real-valued (double) matrix
 *   and supports various matrix computations required in linear algebra.
 *   
 *   Class and method comments are in JavaDoc: https://en.wikipedia.org/wiki/Javadoc
 * 
 * @author scott.sanner@utoronto.ca, <YOUR_EMAIL> alicexiaoting.zhao@utoronto.ca
 *
 */
public class Matrix {

	private int _nRows; // Number of rows in this matrix; nomenclature: _ for data member, n for integer
	private int _nCols; // Number of columns in this matrix; nomenclature: _ for data member, n for integer
	// TODO: add your own data member to represent the matrix content
	//       you could use a 2D array, or an array of Vectors (e.g., for each row)
	private double[][] mat; //create space for double 2D array
	/** Allocates a new matrix of the given row and column dimensions
	 * 
	 * @param rows
	 * @param cols
	 * @throws LinAlgException if either rows or cols is <= 0
	 */
	public Matrix(int rows, int cols) throws LinAlgException {
		// TODO: hint: see the corresponding Vector constructor
		if (rows < 1 || cols < 1) {
			throw new LinAlgException("Both dimensions must be greater than 0");  //throws exception when row or col is less than 1 
		}
		_nRows = rows; 
		_nCols = cols; 
		mat = new double[rows][cols]; //creates double array with dimensions rows and cols
	}
	
	/** Copy constructor: makes a new copy of an existing Matrix m
	 *                    (note: this explicitly allocates new memory and copies over content)
	 * 
	 * @param m
	 */
	public Matrix(Matrix m) {
		// TODO: hint: see the corresponding Vector "copy constructor" for an example
		_nRows = m._nRows; 
		_nCols = m._nCols; 
		mat = new double[_nRows][_nCols]; //creates new 2D array with dimensions _nRows and _nCols 
		for (int y = 0; y < _nRows; y++) {
			for (int z = 0; z < _nCols; z++) {
				mat[y][z] = m.mat[y][z]; //creates the matrix
			}
		}
	}

	/** Constructs a String representation of this Matrix
	 * 
	 */
	public String toString() {
		// TODO: hint: see Vector.toString() for an example
		StringBuilder strbu = new StringBuilder();  
		for (int y = 0; y < _nRows; y++) {
			strbu.append("[ ");
			for (int z = 0; z < _nCols; z++) {
				strbu.append(String.format("%6.3f  ", mat[y][z]));
			}
			strbu.append("] "); 
			strbu.append(String.format("\n")); 
		} 
		return strbu.toString();
	}

	/** Tests whether another Object o (most often a matrix) is a equal to *this*
	 *  (i.e., are the dimensions the same and all elements equal each other?)
	 * 
	 * @param o the object to compare to
	 */
	public boolean equals(Object o) {
		// TODO: hint: see Vector.equals(), you can also use Vector.equals() for checking equality 
		//             of row vectors if you store your matrix as an array of Vectors for rows
		if (o instanceof Matrix) {
			Matrix m = (Matrix)o;
			if (_nRows != m._nRows || _nCols != m._nCols)
				return false; //checks if matrices have the same dimension
			
			for (int a = 0; a < _nRows; a++) {
				for (int b = 0; b < _nCols; b++) {
					if (mat[a][b] != m.mat[a][b])
						return false;  //checks if the values are the same in every index of the matrix
				}
			} return true; 		
		} else 
			return false; 
		// TODO: this should not always return false!
			//return false; // This should not always return false!
	}
	
	/** Return the number of rows in this matrix
	 *   
	 * @return 
	 */
	public int getNumRows() {
		// TODO (this should not return -1!)
		return _nRows;
	}

	/** Return the number of columns in this matrix
	 *   
	 * @return 
	 */
	public int getNumCols() {
		// TODO (this should not return -1!)
		return _nCols;
	}

	/** Return the scalar value at the given row and column of the matrix
	 * 
	 * @param row
	 * @param col
	 * @return
	 * @throws LinAlgException if row or col indices are out of bounds
	 */
	public double get(int row, int col) throws LinAlgException {
		// TODO (this should not return -1!)
		if (row < 0 || row > _nRows -1 || col < 0 || col > _nCols -1) {
			throw new LinAlgException("One or both indices are out of bounds"); //throws exception when index is less than 0 or length of row / array
		}
		double getValue = mat[row][col]; //get value of the matrix at row and column 
		return getValue;
	}
	
	/** Return the Vector of numbers corresponding to the provided row index
	 * 
	 * @param row
	 * @return
	 * @throws LinAlgException if row is out of bounds
	 */
	public Vector getRow(int row) throws LinAlgException {
		// TODO (this should not return null!)
		if (row < 0 || row > _nRows -1) {
			throw new LinAlgException("Row number is out of bounds"); //throws exception when row index is out of bounds
		}
		Vector vecRow = new Vector(_nCols);  // creates new vector with size number of columns in the matrix 
		for (int d = 0; d < _nCols; d++) {
			vecRow.set(d, mat[row][d]); //set the values of the vector with the row selected 
		}
		return vecRow;
	}

	/** Set the row and col of this matrix to the provided val
	 * 
	 * @param row
	 * @param col
	 * @param val
	 * @throws LinAlgException if row or col indices are out of bounds
	 */
	public void set(int row, int col, double val) throws LinAlgException {
		// TODO
		if (row < 0 || row > _nRows -1 || col < 0 || col > _nCols -1) {
			throw new LinAlgException("Row number or column number is out of bounds"); //throws exception when rows out of bounds
		}
		mat[row][col] = val;  //sets matrix at row and col with the input value 
	}
	
	/** Return a new Matrix that is the transpose of *this*, i.e., if "transpose"
	 *  is the transpose of Matrix m then for all row, col: transpose[row,col] = m[col,row]
	 *  (should not modify *this*)
	 * 
	 * @return
	 * @throws LinAlgException
	 */
	public Matrix transpose() throws LinAlgException {
		Matrix transpose = new Matrix(_nCols, _nRows);
		for (int row = 0; row < _nRows; row++) {
			for (int col = 0; col < _nCols; col++) {
				transpose.set(col, row, get(row,col));
			}
		}
		return transpose;
	}

	/** Return a new Matrix that is the square identity matrix (1's on diagonal, 0's elsewhere) 
	 *  with the number of rows, cols given by dim.  E.g., if dim = 3 then the returned matrix
	 *  would be the following:
	 *  
	 *  [ 1 0 0 ]
	 *  [ 0 1 0 ]
	 *  [ 0 0 1 ]
	 * 
	 * @param dim
	 * @return
	 * @throws LinAlgException if the dim is <= 0
	 */
	public static Matrix GetIdentity(int dim) throws LinAlgException {
		// TODO: this should not return null!
		
		if (dim < 1) {
			throw new LinAlgException("EXCEPTION: Size " + dim + " must be greater than 0"); 
		}
		
		Matrix newIdentity = new Matrix(dim,dim); //creates new matrix of size dim
		for (int r = 0; r < dim; r++) {
			for (int c = 0; c < dim; c ++) {
				if (r == c) {
					newIdentity.set(r,c, 1.00); //if the row equals to the column then make value 1
				} else {
					newIdentity.set(r,c, 0.00); //if row does not equal to column set value to 0
				}
			}
		}
		return newIdentity;
	}
	
	/** Returns the Matrix result of multiplying Matrix m1 and m2
	 *  (look up the definition of matrix multiply if you don't remember it)
	 * 
	 * @param m1
	 * @param m2
	 * @return
	 * @throws LinAlgException if m1 columns do not match the size of m2 rows
	 */
	public static Matrix Multiply(Matrix m1, Matrix m2) throws LinAlgException {
		// TODO: this should not return null!
		
		if (m1.getNumCols() != m2.getNumRows()) {
			throw new LinAlgException("Cannot multiply matrix with " + m1.getNumCols() + " columns with a matrix with " + m2.getNumRows()); 
		}
		
		int row = m1.getNumRows(); //number of rows for result matrix
		int col = m2.getNumCols(); //number of columns for result matrix
		double value = 0; 
		Matrix matMult = new Matrix(row, col); //create result matrix
		
		for (int ro = 0; ro < row; ro++) { //access each row 
			Vector vect = m1.getRow(ro);  //get each row of matrix one 
			for (int co = 0; co < col; co++) {
				for (int inside = 0; inside < m1.getNumCols(); inside ++) {
					value = value + vect.get(inside) * m2.get(inside, co); //keep adding product of value from the row with column value 
				} matMult.set(ro, co, value); //set sum of values to specific placement on matrix
				value = 0; //resets value for another index of the matrix
			}
		}
		return matMult;
	}
		
	/** Returns the Vector result of multiplying Matrix m by Vector v (assuming v is a column vector)
	 * 
	 * @param m
	 * @param v
	 * @return
	 * @throws LinAlgException if m columns do match the size of v
	 */
	public static Vector Multiply(Matrix m, Vector v) throws LinAlgException {
		// TODO: this should not return null!
		if (m.getNumCols() != v.getDim()) {
			throw new LinAlgException("Cannot multiply matrix with " + m.getNumCols() + " columns with a vector of dimension " + v.getDim()); 
		}
		
		double valueVec = 0; 
		Vector returnVector = new Vector(m.getNumRows()); 
		
		for (int multRow = 0 ; multRow < m.getNumRows(); multRow ++) {
			Vector vecto = m.getRow(multRow); //get each row of matrix
			for (int vecCol = 0 ; vecCol < m.getNumCols(); vecCol ++) {
				valueVec = valueVec + vecto.get(vecCol) * v.get(vecCol) ; //dot product of each row of the matrix with the vector
			}  returnVector.set(multRow, valueVec);
			valueVec = 0; 
		}
		return returnVector;
	}

}
